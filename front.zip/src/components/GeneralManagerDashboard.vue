<template>
    <div class="customer-dashboard">
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                <h1 class="text-3xl font-bold text-gray-900">Dashboard</h1>
            </div>
        </header>
        <main>
        <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <!-- Replace with your content -->
            <div class="flex flex-col justify-center items-center space-y-4">
                <render-user v-for="user in users" :user="user" @promote-event="promote" :key="user.id" />
            </div>
            <!-- /End replace -->
        </div>
        </main>
    </div>
</template>

<script lang="ts">
    import { defineComponent, onMounted, ref } from "vue";
    import IUser from "@/types/User";
    import RenderUser from "@/components/RenderUser.vue";
    import userAPI from "@/api/user";

    export default defineComponent({
        name: 'GeneralManagerDashboard',
        setup() {
            const users = ref<IUser[]>([]);

            onMounted(() => {
                userAPI.getAllUsers().then(res => {
                    users.value = res.data;
                })
                .catch(err => {
                    console.log(err);
                });
            });

            return {
                users
            }
        },
        components: {
            RenderUser
        },
        methods: {
            promote(payload: { id: number, level: number }) {
                userAPI.promoteUser(payload.id, payload.level)
                .then(async () => {
                    this.users = (await userAPI.getAllUsers()).data;
                })
                .catch(err => console.log(err));
            }
        }
    });
</script>
