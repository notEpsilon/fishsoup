<template>
    <div class="department-manager-dashboard">This is department-manager dashboard</div>
</template>

<script lang="ts">
    import { defineComponent } from "vue";
    export default defineComponent({
        name: 'DepartmentManagerDashboard'
    });
</script>
