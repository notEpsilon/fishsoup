export default interface LoginFormInfo {
    email: string;
    password: string;
}
