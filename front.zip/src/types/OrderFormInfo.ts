export default interface Order {
    address: string;
    city: string;
    phoneNumber: string;
    checked: boolean;
}