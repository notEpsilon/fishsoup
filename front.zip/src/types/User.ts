export default interface User {
    id: number;
    name: string;
    email: string;
    type?: 0 | 1 | 2 | 3
}
