export default interface Product {
    id: number;
    name: string;
    image_link: string;
    price: number;
    amount: number;
}
