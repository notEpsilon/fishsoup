export default interface Navlink {
    name: string;
    href: string;
    current?: boolean;
}
