export default interface RegsiterFormInfo {
    name: string;
    email: string;
    password: string;
    password_confirmation: string;
}
